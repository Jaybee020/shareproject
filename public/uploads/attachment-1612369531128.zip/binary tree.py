import collections

Node = collections.namedtuple('Node', ['left', 'right', 'value'])

def contains(root, value):
   # Base Cases: root is null or key is present at root 
    if root is None: 
        return False
    
    if root.value == value:
        return True
  
    # Key is greater than root's key 
    if root.value < value: 
        return contains(root.right,value) 
    
    # Key is smaller than root's key 
    return contains(root.left,value) 
        
n1 = Node(value=1, left=None, right=None)
n3 = Node(value=3, left=None, right=None)
n2 = Node(value=2, left=n1, right=n3)
print(contains(n2,3))
